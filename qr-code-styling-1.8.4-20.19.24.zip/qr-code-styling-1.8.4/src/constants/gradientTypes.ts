import { GradientTypes } from "../types";

export default {
  radial: "radial",
  linear: "linear"
} as GradientTypes;
