module.exports = {
  semi: true,
  trailingComma: "none",
  singleQuote: false,
  printWidth: 120,
  tabWidth: 2
};
